#include "board_api.h"

ShipPlacement player2PlaceShip(Board board, ShipID ship);
Coordinate player2Action(Board board);